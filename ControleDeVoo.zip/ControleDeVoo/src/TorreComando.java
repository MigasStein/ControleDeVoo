import java.util.ArrayList;
import java.util.List;

public class TorreComando {

	private List<Aviao> voosMonitorados;

    public TorreComando() {
        this.voosMonitorados = new ArrayList<>();
    }

    public void monitorarVoo(Aviao aviao) {
        voosMonitorados.add(aviao);
        System.out.println("[TORRE]  Voo " + aviao.getCodigoVoo() + " detectado no radar.");
    }

    public void autorizarPouso(String codigoVoo) {
        for (Aviao aviao : voosMonitorados) {
            if (aviao.getCodigoVoo().equalsIgnoreCase(codigoVoo)) {
                if (aviao.getStatus().equals("Em Voo")) {
                    aviao.alternarStatus("Pousado");
                    System.out.println("[TORRE] Voo " + codigoVoo + " autorizado a pousar. Pista liberada.");
                } else {
                    System.out.println("[TORRE] Comando inválido. O voo " + codigoVoo + " já está no solo.");
                }
                return;
            }
        }
        System.out.println("[TORRE] Erro: Voo " + codigoVoo + " não encontrado no radar.");
    }

    public void autorizarDecolagem(String codigoVoo) {
        for (Aviao aviao : voosMonitorados) {
            if (aviao.getCodigoVoo().equalsIgnoreCase(codigoVoo)) {
                if (aviao.getStatus().equals("Pousado")) {
                    aviao.alternarStatus("Em Voo");
                    System.out.println("[TORRE] Voo " + codigoVoo + " autorizado a decolar. Subida livre!");
                } else {
                    System.out.println("[TORRE] Comando inválido. O voo " + codigoVoo + " já está no ar.");
                }
                return;
            }
        }
        System.out.println("[TORRE] Erro: Voo " + codigoVoo + " não encontrado no radar.");
    }

    public void exibirRadar() {
        System.out.println("\n===  TELA DO RADAR DA TORRE ===");
        if (voosMonitorados.isEmpty()) {
            System.out.println("Nenhuma aeronave na região.");
        } else {
            for (Aviao aviao : voosMonitorados) {
                aviao.exibirDados();
            }
        }
        System.out.println("=================================\n");
    }
}