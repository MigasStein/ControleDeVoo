
public class Main {
    public static void main(String[] args) {
    
    	System.out.println("=== INICIANDO SISTEMA DE TRÁFEGO AÉREO ===\n");

        TorreComando torre = new TorreComando();

       
        Aviao voo1 = new Aviao("AZU1024", "Azul");
        Aviao voo2 = new Aviao("GLO2030", "Gol");
        Aviao voo3 = new Aviao("TAM3900", "Latam");
        
        torre.monitorarVoo(voo1);
        torre.monitorarVoo(voo2);
        torre.monitorarVoo(voo3);
       
        torre.exibirRadar();

        torre.autorizarPouso("AZU1024");
        torre.autorizarPouso("GLO2030");
                
        torre.autorizarPouso("AZU1024");
        
        torre.exibirRadar();
        
        torre.autorizarDecolagem("AZU1024");
      
        torre.exibirRadar();
    }
}
