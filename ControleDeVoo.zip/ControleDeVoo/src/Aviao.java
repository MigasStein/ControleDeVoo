
public class Aviao {

	private String codigoVoo;
	private String companhia;
	private String status; 

	public Aviao(String codigoVoo, String companhia) {
		this.codigoVoo = codigoVoo;
		this.companhia = companhia;
		this.status = "Em Voo";
	}

	public void alternarStatus(String novoStatus) {
		this.status = novoStatus;
	}

	public void exibirDados() {
		System.out.println("Voo: " + codigoVoo + " | Cia: " + companhia + " | Status: " + status);
	}

	
	public String getCodigoVoo() {
		return codigoVoo;
	}

	public String getStatus() {
		return status;
	}
}